# Carregar os pacotes necessários
install.packages("caTools")  # Para dividir o dataset
install.packages("Metrics")  # Para métricas de erro
library(caTools)
library(Metrics)

# Carregar o dataset
df <- read.csv("C:\\Users\\user\\Documents\\Pesquisas - EstatiAI\\df_pacientes.csv")

# Selecionar as variáveis independentes e a variável dependente
X <- df[, c("idade", "nveldeconscinciaglasgow", "rass", "icdsc",
            "fssicurolar", "fssicutransfernciadaposiosupinaprasentada",
            "fssicutransfernciadaposiosupinaparaemp",
            "fssicusentarnabeiradadacama", "fssicuandar",
            "fsstotal", "diagnsticoprincipal_numerico")]

y <- df$condutasintervenoes_numerico

# Dividir os dados em treino e teste (70% treino, 30% teste)
set.seed(42)
split <- sample.split(y, SplitRatio = 0.7)
X_train <- subset(X, split == TRUE)
X_test <- subset(X, split == FALSE)
y_train <- subset(y, split == TRUE)
y_test <- subset(y, split == FALSE)

# Treinar o modelo de regressão linear
modelo <- lm(y_train ~ ., data = X_train)

# Fazer previsões no conjunto de teste
y_pred <- predict(modelo, newdata = X_test)

# Avaliar o modelo
mse <- mse(y_test, y_pred)
r2 <- 1 - (sum((y_test - y_pred)^2) / sum((y_test - mean(y_test))^2))

# Exibir resultados
print(paste("Mean Squared Error (MSE):", mse))
print(paste("R-squared (R²):", r2))
