df <- read.csv("C:\\Users\\user\\Documents\\Pesquisas - EstatiAI\\df_pacientes.csv")
#view(df_pacientes.csv)

#Possíveis analises
# •	Comparar FSS-ICU entre pacientes com ICDSC ≥ 4 (indicação de delirium) e  < 4 usando o teste t ou Mann-Whitney U ( ou o que vc achar melhor) essas sugestões foram sugeridas pelo que eu vi previamente em minhas consultas.
# •	Comparação dos resultados das escalas entre grupos de pacientes que receberam diferentes condutas terapêuticas.
# •	Calcular correlação entre Glasgow e FSS-ICU, e entre RASS e ICDSC
# •	Regressão linear para prever FSS-ICU com base em Glasgow, RASS e ICDSC.
# •	Regressão linear para prever as condutas terapêuticas ocupacionais com base nas escalas, idades e diagnostico
# •	Frequências e percentuais para variáveis categóricas (Diagnóstico, Condutas).



#1) •	Comparar FSS-ICU entre pacientes com ICDSC ≥ 4 (indicação de delirium) e  < 4 usando o teste t ou Mann-Whitney U ( ou o que vc achar melhor) essas sugestões foram sugeridas pelo que eu vi previamente em minhas consultas.

##
## 0–3 pontos: Sem delírio.
## 4–8 pontos: Delírio provável ou presente.


df$ICDSC[df$ICDSC == "NÃO AVALIADO"] = NA
df$ICDSC = as.numeric(df$ICDSC)
df$ICDSC

df$icdsc_4 = ifelse(df$ICDSC >= 4, 1, 0)
df$icdsc_4 = as.factor(df$icdsc_4)
table(df$icdsc_4)


###############################################

# Função para converter todas as colunas para o tipo character
convert_to_character <- function(df) {
  df[] <- lapply(df, as.character)
  return(df)
}

# Função para normalizar os nomes das colunas
library(stringr)
normalize_column_names <- function(df) {
  # Remover acentuação
  colnames(df) <- iconv(colnames(df), from = "UTF-8", to = "ASCII//TRANSLIT")

  # Converter para minúsculas
  colnames(df) <- tolower(colnames(df))

  # Substituir espaços por underscores
  colnames(df) <- str_replace_all(colnames(df), " ", "_")

  # Remover caracteres especiais, mantendo apenas letras, números e underscores
  colnames(df) <- gsub("[^a-z0-9_]", "", colnames(df))

  # Substituir múltiplos underscores consecutivos por um único underscore
  colnames(df) <- gsub("_+", "_", colnames(df))

  # Remover underscores no início ou fim dos nomes de colunas
  colnames(df) <- gsub("^_|_$", "", colnames(df))

  return(df)
}

df = normalize_column_names(df)

###########################################################

#df$fssicutransferenciadaposicaosupinaparaempe[df$fssicutransferenciadaposicaosupinaparaempe == "Não avaliado"] = NA
#df$fssicutransferenciadaposicaosupinaparaempe = as.numeric(df$fssicutransferenciadaposicaosupinaparaempe)
#df$fssicutransferenciadaposicaosupinaparaempe

#df$fssicuandar = as.numeric(df$fssicuandar)
#df$fssicuandar

#df$fssicutransferenciadaposicaosupinaprasentada = as.numeric(df$fssicutransferenciadaposicaosupinaprasentada)
#df$fssicutransferenciadaposicaosupinaprasentada

#df$fssicutransferenciadaposicaosupinaprasentada = as.numeric(df$fssicutransferenciadaposicaosupinaprasentada)
#df$fssicutransferenciadaposicaosupinaprasentada

#df$fssicurolar = as.numeric(df$fssicuandar)
#df$fssicurolar

#df$fssicusentarnabeiradadacama = as.numeric(df$fssicusentarnabeiradadacama)
#df$fssicusentarnabeiradadacama

#df$fsstotal = as.numeric(df$fsstotal)
#df$fsstotal

#df$icdsc_4[is.na(df$icdsc_4)] = 0
#df[c('fssicurolar','icdsc_4')]

#df$fssicurolar[is.na(df$fssicurolar)] = 0
wilcox.test(df$fssicurolar ~ df$icdsc, conf.level = 0.95,correct = TRUE,)

#df$fssicutransferenciadaposicaosupinaprasentada[is.na(df$fssicutransferenciadaposicaosupinaprasentada)] = 0
wilcox.test(df$fssicutransferenciadaposicaosupinaprasentada ~ df$icdsc_4)

#df$fssicutransferenciadaposicaosupinaparaempe[is.na(df$fssicutransferenciadaposicaosupinaparaempe)] = 0
wilcox.test(df$fssicutransferenciadaposicaosupinaprasentada ~ df$icdsc_4)

#df$fssicusentarnabeiradadacama[is.na(df$fssicusentarnabeiradadacama)] = 0
wilcox.test(df$fssicusentarnabeiradadacama ~ df$icdsc_4)

#df$fssicuandar[is.na(df$fssicuandar)] = 0
wilcox.test(df$fssicuandar ~ df$icdsc_4)
###########################################################
## CLASSIFICACAO EM DOIS GRUPOS Condutas e Intervencoes
df[c('condutasintervencaooes')]


# Carregar o pacote necessário
library(dplyr)

# Carregar o dataset
df <- read.csv("~/Pesquisas - EstatiAI/df_pacientes.csv")

# Função para classificar condutas terapêuticas
classificar_conduta <- function(conduta) {
  motoras_fisicas <- c("MOVIMENTAÇÃO", "ÓRTESE", "MMSS", "MMII", "COORDENAÇÃO",
                       "EDUCAÇÃO", "BANDAGEM", "ROLAR", "SUPINA", "ANDAR", "SENTAR", "SEDESTAÇÃO")

  cognitivas_emocionais <- c("ESTIMULAÇÃO COGNITIVA", "ORIENTAÇÃO", "TEMPO-ESPAÇO",
                             "COMUNICAÇÃO", "DELIRIUM", "ESTRÉSSE", "ALERTA")

  if (any(grepl(paste(motoras_fisicas, collapse = "|"), conduta))) {
    return("Motoras/Físicas")
  } else if (any(grepl(paste(cognitivas_emocionais, collapse = "|"), conduta))) {
    return("Cognitivas/Emocionais")
  } else {
    return("Não classificado")
  }
}

# Aplicar a função de classificação às condutas
df$Categoria_de_Conduta <- sapply(df$condutasintervencaooes, classificar_conduta)

# Visualizar as primeiras linhas do dataframe atualizado
head(df)

###########################################################
# Instalar o pacote dplyr se ainda não estiver instalado
install.packages("dplyr")

# Carregar o pacote
library(dplyr)

# Renomear colunas usando dplyr
df <- df %>%
  rename(genero = gnero)
    #nome_nov = nome_antigo

df <- df %>%
  rename(mes = ms)

# Criar as colunas 'mes' e 'ano' separando a coluna 'ms'
df <- separate(df, mes, into = c("mes", "ano"), sep = "/")
df

###########################################################

library(statgsa)

#Cross Tables - Univariate Analysis
adaptive_cross_table(df, 'genero')

# Correlação entre duas variáveis (coluna1 e coluna2)
# Calcular a matriz de correlação entre todas as variáveis numéricas
matriz_correlacao <- cor(df, method = "pearson")
matriz_correlacao <- cor.test(df$'fssicurolar',df$'icdsc',)
print(matriz_correlacao)


# Instalar o pacote corrplot se ainda não tiver
install.packages("corrplot")

# Carregar o pacote
library(corrplot)

# Gerar o gráfico da matriz de correlação
corrplot(matriz_correlacao, method = "circle")

# Exemplo com três variáveis independentes
# •	Regressão linear para prever FSS-ICU com base em Glasgow, RASS e ICDSC.
modelo1 <- lm(fssicurolar ~ nveldeconscinciaglasgow + rass + icdsc, data = df)
summary(modelo1)
plot(modelo1)


summary(df)
modelo4 <- lm(condutasintervenoes_numerico ~ idade +
              diagnsticoprincipal_numerico, data = df)
summary(modelo4)
plot(modelo4)


#Dropando as colunas do df
df$datadoatendimento = NULL
df$numerodeatendimento2022 = NULL
df$nomedopaciente = NULL
df$atendimento = NULL
df$rghc
df$carimbodedatahora = NULL
df$rghc = NULL
df$mes = NULL
df$ms  = NULL
summary(df)

# Correlacao Person
corr.r()

##########################################################
df_planilha <- df %>% mutate(grupo = 'planilha') %>% filter(!is.na(tempo_totem_abertura_de_ficha_min))
df_tasy <- fd %>% mutate(grupo = 'tasy') %>% filter(!is.na(tempo_totem_abertura_de_ficha_min))
dados_combinados <- bind_rows(df_planilha, df_tasy)

estatisticas = dados_combinados %>%
  group_by(mes, grupo) %>%
  summarise(media = mean(tempo_totem_abertura_de_ficha_min, na.rm=T),
            sd = sd(tempo_totem_abertura_de_ficha_min, na.rm=T)) %>%
  mutate(ymin = media - sd, ymax = media + sd)
estatisticas$ymin = ifelse(estatisticas$ymin <= 0, 0.01, estatisticas$ymin)

ggplot() +
  # Não Parametrico
  geom_violin(data = dados_combinados, aes(x = grupo, y = tempo_totem_abertura_de_ficha_min, fill = grupo),
              alpha = 0.2, show.legend = T) +
  geom_boxplot(data = dados_combinados, aes(x = grupo, y = tempo_totem_abertura_de_ficha_min, fill = grupo),
               width = 0.2, alpha = 0.8, position = position_dodge(width = 0.75), show.legend = T) +
  # Parametrico
  # geom_errorbar(data = estatisticas, aes(x = grupo, y = media, ymin = ymin, ymax = ymax),
  #               color='red', width = 0.1, position = position_dodge(width = 0.75)) +
  # geom_point(data = estatisticas, aes(x = grupo, y = media),
  #            color = "red", size = 2, position = position_dodge(width = 0.75)) +
  # Outros
  scale_fill_manual(values = c('planilha' = '#ffc8dd', 'tasy' = '#bde0fe'),
                    labels = c('Planilha Manual','Planilha de\nSistema Eletronico')) +
  labs(x=NULL, y='Tempo (min)', title='Tempo Totem - Abertura de Ficha', fill=NULL) +
  scale_x_discrete(labels = c('Planilha Manual','Planilha de\nSistema Eletronico')) +
  scale_y_continuous(limits = c(0, 30), breaks=seq(from = 0, to = 1000, by = 5)) +
  theme_minimal() + theme(
    plot.subtitle = element_text(hjust = 0.5), plot.title = element_text(hjust = 0.5),
    axis.text.x = element_blank(), axis.title.x = element_blank()
  ) + theme(legend.position = "bottom") +
  facet_grid(~mes)

ggsave("pormes_tempo_totem_abertura_de_ficha_min.jpg", height=10, width=20, units="cm", dpi= 600)


















