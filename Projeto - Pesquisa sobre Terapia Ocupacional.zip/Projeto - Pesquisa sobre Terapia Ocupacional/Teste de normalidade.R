# Carregar o dataset
df <- read.csv("C:\\Users\\user\\Documents\\Pesquisas - EstatiAI\\df_pacientes.csv")

# Selecionar as variáveis de interesse
variaveis <- df[, c("idade", "nveldeconscinciaglasgow", "rass", "icdsc",
                    "fssicurolar", "fssicutransfernciadaposiosupinaprasentada",
                    "fssicutransfernciadaposiosupinaparaemp",
                    "fssicusentarnabeiradadacama", "fssicuandar",
                    "fsstotal", "diagnsticoprincipal_numerico",
                    "condutasintervenoes_numerico")]

# Função para aplicar o teste de normalidade Shapiro-Wilk em cada coluna
resultado_normalidade <- sapply(variaveis, function(coluna) {
  shapiro.test(coluna)$p.value
})

# Exibir os resultados do p-value para cada variável
print(resultado_normalidade)


# Carregar os valores de p do teste de normalidade
valores_p <- c(idade = 7.246873e-02,
               nveldeconscinciaglasgow = 1.221437e-05,
               rass = 2.287643e-05,
               icdsc = 4.826133e-03,
               fssicurolar = 1.322825e-08,
               fssicutransfernciadaposiosupinaprasentada = 1.632046e-08,
               fssicutransfernciadaposiosupinaparaemp = 1.296113e-09,
               fssicusentarnabeiradadacama = 1.509799e-08,
               fssicuandar = 3.994622e-10,
               fsstotal = 1.402688e-08,
               diagnsticoprincipal_numerico = 3.096725e-01,
               condutasintervenoes_numerico = 6.991208e-01)

# Nomear os rótulos das variáveis
nomes <- c("Idade", "Glasgow", "RASS", "ICDSC", "FSS ICU Rolar",
           "FSS ICU Supina p/ Sentada", "FSS ICU Supina p/ Em pé",
           "FSS ICU Sentar Beira Cama", "FSS ICU Andar", "FSS Total",
           "Diagnóstico", "Condutas Terapêuticas")

# Plotar o gráfico de barras
bp <- barplot(valores_p,
              names.arg = rep("", length(nomes)), # Esconder os nomes inicialmente
              las = 2,
              col = "lightblue",
              main = "Resultado do Teste de Normalidade (p-valores)",
              ylim = c(0, 1),
              ylab = "p-valor")

# Adicionar a linha horizontal em p=0.05
abline(h = 0.05, col = "red", lty = 2)

# Colocar os valores em cima das barras
text(x = bp, y = valores_p, label = round(valores_p, 3), pos = 3, cex = 0.8)

# Adicionar os nomes das variáveis rotacionados a 45 graus
text(x = bp, y = par("usr")[3] - 0.05, labels = nomes, srt = 45, adj = 1, xpd = TRUE, cex = 0.7)

